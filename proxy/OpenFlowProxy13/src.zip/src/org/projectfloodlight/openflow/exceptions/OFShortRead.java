package org.projectfloodlight.openflow.exceptions;

public class OFShortRead extends Exception {
    private static final long serialVersionUID = 1L;

}
