package org.projectfloodlight.openflow.exceptions;

public class OFUnsupported extends Exception {

    private static final long serialVersionUID = 1L;

}
